import { createSlice } from "@reduxjs/toolkit";

const leaveSlice = createSlice({
    name: "leaves",
    initialState: {
        leaveList: []
    },
    reducers: {

        addLeave: (state, action) => {
            state.leaveList.push(action.payload);
        },

        deleteLeave: (state, action) => {
            state.leaveList = state.leaveList.filter(
                leave => leave.id !== action.payload
            );
        },

        approveLeave: (state, action) => {
            const leave = state.leaveList.find(
                leave => leave.id === action.payload
            );
            if (leave) leave.status = "Approved";
        },

        rejectLeave: (state, action) => {
            const leave = state.leaveList.find(
                leave => leave.id === action.payload
            );
            if (leave) leave.status = "Rejected";
        }

    }
});

export const { addLeave, deleteLeave, approveLeave, rejectLeave } =
    leaveSlice.actions;

export default leaveSlice.reducer;