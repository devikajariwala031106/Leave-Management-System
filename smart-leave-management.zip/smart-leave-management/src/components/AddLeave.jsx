import { useState } from "react";
import { useDispatch } from "react-redux";
import { addLeave } from "../features/leaveSlice";

function AddLeave() {

    const dispatch = useDispatch();

    const [form, setForm] = useState({
        name: "",
        reason: "",
        date: "",
        status: "Pending"
    });

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    }

    const handleSubmit = (e) => {
        e.preventDefault();

        dispatch(addLeave({
            id: Date.now(),
            ...form
        }));

        setForm({ name: "", reason: "", date: "", status: "Pending" });
    }

    return (

        <form className="leave-form" onSubmit={handleSubmit}>

            <input
                type="text"
                name="name"
                placeholder="Employee Name"
                value={form.name}
                onChange={handleChange}
                required
            />

            <input
                type="date"
                name="date"
                value={form.date}
                onChange={handleChange}
                required
            />

            <input
                type="text"
                name="reason"
                placeholder="Leave Reason"
                value={form.reason}
                onChange={handleChange}
                required
            />

            <button type="submit">Apply Leave</button>

        </form>
    );
}

export default AddLeave;