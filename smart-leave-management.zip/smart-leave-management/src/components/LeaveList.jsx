import { useSelector } from "react-redux";
import LeaveCard from "./LeaveCard";

function LeaveList() {

    const leaves = useSelector(state => state.leaves.leaveList);

    return (

        <div className="leave-list">

            {leaves.map(leave => (
                <LeaveCard key={leave.id} leave={leave} />
            ))}

        </div>

    );
}

export default LeaveList;