import React from "react";

const Sidebar = () => {
    return (
        <div className="w-64 bg-indigo-700 text-white min-h-screen p-5">
            <h1 className="text-2xl font-bold mb-10">Leave System</h1>

            <ul className="space-y-4">
                <li className="hover:bg-indigo-500 p-2 rounded cursor-pointer">
                    Dashboard
                </li>

                <li className="hover:bg-indigo-500 p-2 rounded cursor-pointer">
                    Apply Leave
                </li>

                <li className="hover:bg-indigo-500 p-2 rounded cursor-pointer">
                    Leave Requests
                </li>

                <li className="hover:bg-indigo-500 p-2 rounded cursor-pointer">
                    Reports
                </li>
            </ul>
        </div>
    );
};

export default Sidebar;