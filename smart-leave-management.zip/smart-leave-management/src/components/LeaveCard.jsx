import { useDispatch } from "react-redux";
import { deleteLeave, approveLeave, rejectLeave }
    from "../features/leaveSlice";

function LeaveCard({ leave }) {

    const dispatch = useDispatch();

    return (

        <div className="leave-card">

            <h3>{leave.name}</h3>

            <p>Date: {leave.date}</p>

            <p>Reason: {leave.reason}</p>

            <p>Status:
                <span className={`status ${leave.status.toLowerCase()}`}>
                    {leave.status}
                </span>
            </p>

            <div className="card-buttons">

                <button
                    className="approve-btn"
                    onClick={() => dispatch(approveLeave(leave.id))}
                >
                    Approve
                </button>

                <button
                    className="update-btn"
                    onClick={() => dispatch(rejectLeave(leave.id))}
                >
                    Reject
                </button>

                <button
                    className="delete-btn"
                    onClick={() => dispatch(deleteLeave(leave.id))}
                >
                    Delete
                </button>

            </div>

        </div>
    );
}

export default LeaveCard;