import { useState } from "react";
import { useSelector } from "react-redux";
import LeaveCard from "./LeaveCard";

function SearchFilter() {

    const leaves = useSelector(state => state.leaves.leaveList);

    const [search, setSearch] = useState("");

    const filtered = leaves.filter(leave =>
        leave.name.toLowerCase().includes(search.toLowerCase())
    );

    return (

        <div>

            <input
                className="search"
                placeholder="Search Employee..."
                onChange={(e) => setSearch(e.target.value)}
            />

            <div className="leave-list">
                {filtered.map(leave => (
                    <LeaveCard key={leave.id} leave={leave} />
                ))}
            </div>

        </div>

    )
}

export default SearchFilter;