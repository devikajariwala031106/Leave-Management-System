import AddLeave from "../components/AddLeave";
import SearchFilter from "../components/SearchFilter";

function Dashboard() {

    return (

        <div className="dashboard">

            <h1>Smart Leave Management System</h1>

            <AddLeave />

            <SearchFilter />

        </div>

    )

}

export default Dashboard;